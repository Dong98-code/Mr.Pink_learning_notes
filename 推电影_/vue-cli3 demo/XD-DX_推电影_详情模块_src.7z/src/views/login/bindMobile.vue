<template>
    <div>
        <HeadTop head-title="绑定手机" go-back="true" ></HeadTop>
    </div>
</template>

<script>
    import HeadTop from '@/components/header/Head'
    export default {
        name: "bindMobile",
        components:{
            HeadTop
        }
    }
</script>

<style scoped>

</style>